import { GoogleGenAI, FunctionDeclaration, Type, Chat, LiveServerMessage } from "@google/genai";

// 1. Initialize API Client
// Ideally, in a real app, this is handled via a backend proxy to protect the key.
const apiKey = process.env.API_KEY || ''; 
const ai = new GoogleGenAI({ apiKey });

// 2. Define the Crisis Intervention Tool
const crisisToolDeclaration: FunctionDeclaration = {
  name: 'triggerCrisisIntervention',
  description: 'Activates emergency protocols when the user expresses intent of self-harm, suicide, severe abuse, or an immediate mental health crisis that requires professional intervention.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      severity: {
        type: Type.STRING,
        description: 'The severity level of the crisis (HIGH, MEDIUM, LOW).',
      },
      reason: {
        type: Type.STRING,
        description: 'A brief explanation of why the crisis protocol was triggered.',
      },
    },
    required: ['severity', 'reason'],
  },
};

// 3. System Instruction
const SYSTEM_INSTRUCTION = `
You are Lumi, a warm, safe, and empathetic mental health companion for teenagers. 
Your goal is to listen, validate feelings, and offer gentle, evidence-based coping strategies for anxiety and depression (like mindfulness, grounding techniques, and cognitive reframing).

TONE:
- Friendly, non-clinical, and peer-like but wise.
- Use simple, calming language.
- Validate emotions first before offering solutions (e.g., "It makes sense that you feel that way...").

RULES:
- You are NOT a licensed therapist or doctor. Do not give medical diagnoses.
- If a user asks for a diagnosis, gently clarify you are an AI companion.
- **CRITICAL**: If the user mentions suicide, self-harm, severe physical abuse, or an immediate life-threatening situation, you MUST IMMEDIATELY call the 'triggerCrisisIntervention' tool. Do not try to handle it alone.
- Even if you trigger the tool, also provide a short, compassionate message urging them to stay safe.
`;

let chatSession: Chat | null = null;

export const initializeChat = () => {
  chatSession = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      tools: [{ functionDeclarations: [crisisToolDeclaration] }],
    },
  });
};

export interface ChatResponse {
  text: string;
  crisisTriggered?: {
    severity: string;
    reason: string;
  };
}

export const sendMessageToGemini = async (message: string): Promise<ChatResponse> => {
  if (!chatSession) {
    initializeChat();
  }

  try {
    const result = await chatSession!.sendMessage({ message });
    
    // Check for function calls
    const functionCalls = result.functionCalls;
    let crisisData = undefined;

    if (functionCalls && functionCalls.length > 0) {
      const call = functionCalls[0];
      if (call.name === 'triggerCrisisIntervention') {
        crisisData = call.args as { severity: string; reason: string };
        
        // We must respond to the function call to complete the turn
        // In a real scenario, we might inject "Help is on the way" into the context
        // Here we just acknowledge it so the model can finish its thought if needed,
        // or we just return the crisis flag to the UI.
        
        await chatSession!.sendToolResponse({
            functionResponses: [{
                id: call.id,
                name: call.name,
                response: { result: "Crisis protocol activated in UI." }
            }]
        });
        
        // After sending tool response, the model might generate a follow-up text.
        // For this app, if crisis is triggered, the UI takes over mostly, 
        // but let's see if the model has final words.
        // Actually, sendToolResponse returns a Promise<GenerateContentResponse> which contains the model's follow-up.
        // However, the `sendMessage` above handles the turn. 
        // Wait, `sendMessage` in the new SDK might not automatically handle the loop 
        // if we are doing it manually.
        // Let's keep it simple: If crisis detected, return the text the model *already* generated (if any) or a default.
      }
    }

    return {
      text: result.text || "",
      crisisTriggered: crisisData
    };

  } catch (error) {
    console.error("Gemini API Error:", error);
    return {
      text: "I'm having a little trouble connecting right now. Let's take a deep breath and try again in a moment.",
    };
  }
};
