import React, { useState } from 'react';
import { Therapist } from '../types';
import { Phone, Video, Calendar, X, ShieldAlert } from 'lucide-react';

interface TherapistModalProps {
  onClose: () => void;
  isOpen: boolean;
}

const MOCK_THERAPISTS: Therapist[] = [
  {
    id: '1',
    name: 'Dr. Sarah Chen',
    specialty: 'Adolescent Anxiety & Trauma',
    availability: 'Available Now',
    imageUrl: 'https://picsum.photos/200/200',
    contact: '+1-555-0101'
  },
  {
    id: '2',
    name: 'Dr. James Wilson',
    specialty: 'Depression & Mood Disorders',
    availability: 'Next slot: 20 min',
    imageUrl: 'https://picsum.photos/201/201',
    contact: '+1-555-0102'
  }
];

const TherapistModal: React.FC<TherapistModalProps> = ({ onClose, isOpen }) => {
  const [connectingId, setConnectingId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleConnect = (id: string) => {
    setConnectingId(id);
    // Simulate connection
    setTimeout(() => {
        alert("Connecting you to the secure line...");
        setConnectingId(null);
        onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden relative z-10 animate-[float_0.3s_ease-out]">
        <div className="bg-red-50 p-6 border-b border-red-100 flex items-start gap-4">
          <div className="p-3 bg-red-100 rounded-full text-red-600">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-900">Support Resources Detected</h3>
            <p className="text-slate-600 text-sm mt-1">
              It sounds like you're going through a very tough time. We want to make sure you're safe. Here are professionals who can help right now.
            </p>
          </div>
        </div>

        <div className="p-6">
          <h4 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4">Available Specialists</h4>
          
          <div className="space-y-4">
            {MOCK_THERAPISTS.map((therapist) => (
              <div key={therapist.id} className="flex items-center gap-4 p-4 rounded-xl border border-slate-100 hover:border-lumi-200 hover:bg-lumi-50 transition-all group">
                <img 
                  src={therapist.imageUrl} 
                  alt={therapist.name} 
                  className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-sm"
                />
                <div className="flex-1">
                  <h5 className="font-bold text-slate-800">{therapist.name}</h5>
                  <p className="text-xs text-slate-500">{therapist.specialty}</p>
                  <span className="inline-block mt-1 px-2 py-0.5 bg-green-100 text-green-700 text-[10px] font-bold rounded-full">
                    {therapist.availability}
                  </span>
                </div>
                <div className="flex gap-2">
                    <button 
                        onClick={() => handleConnect(therapist.id)}
                        disabled={!!connectingId}
                        className="p-3 bg-lumi-600 text-white rounded-full hover:bg-lumi-700 shadow-lg shadow-lumi-200 transition-all active:scale-95"
                    >
                        {connectingId === therapist.id ? (
                            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                            <Video className="w-5 h-5" />
                        )}
                    </button>
                    <button className="p-3 bg-white border border-slate-200 text-slate-600 rounded-full hover:bg-slate-50 transition-all">
                        <Phone className="w-5 h-5" />
                    </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 p-4 bg-slate-50 rounded-xl">
            <h4 className="font-semibold text-slate-800 mb-2">Immediate Helplines</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                <a href="tel:988" className="flex items-center gap-2 text-lumi-700 hover:underline font-medium">
                    <Phone className="w-4 h-4" /> 988 (Suicide & Crisis)
                </a>
                <a href="sms:741741" className="flex items-center gap-2 text-lumi-700 hover:underline font-medium">
                    <span className="font-bold border border-current px-1 rounded text-[10px]">TXT</span> Text HOME to 741741
                </a>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 p-4 border-t border-slate-100 flex justify-end">
          <button 
            onClick={onClose}
            className="px-6 py-2 text-slate-500 hover:text-slate-800 font-medium text-sm transition-colors"
          >
            I'm okay now, return to chat
          </button>
        </div>
      </div>
    </div>
  );
};

export default TherapistModal;
