import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';

interface BreathingWidgetProps {
  onClose: () => void;
  isOpen: boolean;
}

const BreathingWidget: React.FC<BreathingWidgetProps> = ({ onClose, isOpen }) => {
  const [step, setStep] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  
  useEffect(() => {
    if (!isOpen) return;
    
    // 4-7-8 Breathing (Simplified for UI visual: 4-4-4)
    const interval = setInterval(() => {
      setStep((prev) => {
        if (prev === 'Inhale') return 'Hold';
        if (prev === 'Hold') return 'Exhale';
        return 'Inhale';
      });
    }, 4000);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-sky-900/80 backdrop-blur-md">
      <button 
        onClick={onClose}
        className="absolute top-6 right-6 text-white/70 hover:text-white transition-colors"
      >
        <X className="w-8 h-8" />
      </button>

      <div className="text-center flex flex-col items-center">
        <h3 className="text-white/90 text-2xl font-light mb-12 tracking-widest uppercase">
          {step}
        </h3>

        <div className="relative w-64 h-64 flex items-center justify-center">
            {/* Outer rings */}
            <div 
                className={`absolute inset-0 rounded-full border border-white/20 transition-all duration-[4000ms] ease-in-out ${
                    step === 'Inhale' ? 'scale-150 opacity-100' : 'scale-100 opacity-50'
                }`}
            ></div>
             <div 
                className={`absolute inset-0 rounded-full border border-white/20 transition-all duration-[4000ms] ease-in-out delay-75 ${
                    step === 'Inhale' ? 'scale-125 opacity-100' : 'scale-75 opacity-30'
                }`}
            ></div>

            {/* Core circle */}
            <div 
                className={`w-32 h-32 bg-white/20 rounded-full blur-xl transition-all duration-[4000ms] ease-in-out ${
                    step === 'Inhale' ? 'scale-150 bg-sky-300/40' : step === 'Exhale' ? 'scale-75 bg-indigo-300/20' : 'scale-100 bg-white/30'
                }`}
            ></div>
            
            <div 
                className={`relative z-10 w-32 h-32 bg-gradient-to-tr from-sky-200 to-indigo-200 rounded-full shadow-[0_0_50px_rgba(255,255,255,0.3)] transition-all duration-[4000ms] ease-in-out ${
                    step === 'Inhale' ? 'scale-110' : 'scale-90'
                }`}
            ></div>
        </div>

        <p className="text-white/60 mt-12 max-w-xs text-sm">
          Focus on your breath. Let the anxiety float away with each exhale.
        </p>
      </div>
    </div>
  );
};

export default BreathingWidget;
